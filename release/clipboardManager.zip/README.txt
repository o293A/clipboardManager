To create a nice shortcut, use the icon : 
clipboard_manager.ico

The .dll file is used if you dont have mingw 64bit compiller in path for works the .exe
Keep it next to the exe